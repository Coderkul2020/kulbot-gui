(window["webpackJsonpGUI"] = window["webpackJsonpGUI"] || []).push([["zh_TW-steps"],{

/***/ "./src/lib/libraries/decks/steps/add-effects.zh_TW.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-effects.zh_TW.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/62bf6bfa8f606e548903e05a9c00c930.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/add-variable.zh_TW.gif":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-variable.zh_TW.gif ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/af627820e3114b93ef21d4a7de42e80b.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-add-sound.zh_TW.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-add-sound.zh_TW.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ddb5a5a7284f669a2c30d41b4ddf063d.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-change-color.zh_TW.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-change-color.zh_TW.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3dfc8d5cdedb3e5e2a737e346bab51f8.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-jump.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-jump.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f5a1783b7dc2aeac29c16cca5c683300.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-move.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-move.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/728ba051b0ac7b16e0aa4a320f70f506.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-say-something.zh_TW.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-say-something.zh_TW.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f5fe7b4329c7728162f3383154c25b4f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-talk.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-talk.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8ec069e13e90bb47735837abc3e07cb7.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/change-size.zh_TW.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/change-size.zh_TW.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4d0fe43ca32b2e96afca682909802332.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-change-score.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-change-score.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b6cdd205c5e99bf7808ab16e73817b74.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_TW.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_TW.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/911ef52fdb429b1c3e80a364a1f17d7f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-play-sound.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-play-sound.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d63a5fba92492bab99136021a79d43a3.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-right-left.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-right-left.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c20f444ba23534c6be1f9910176785db.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-up-down.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-up-down.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7c3cee97eda772af1d4585b4c684bcc4.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-backdrop.zh_TW.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-backdrop.zh_TW.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/41dfa445485f7a81540bded1568a600f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-collect.zh_TW.png":
/*!************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-collect.zh_TW.png ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d85331a416a9a79b829ced3d0e104e88.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-glide.zh_TW.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-glide.zh_TW.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5d3949c26ee9df35dfc3699d356edd5b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-say.zh_TW.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-say.zh_TW.png ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f5114d2193b76184f5aa2f80b063f232.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-score.zh_TW.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-score.zh_TW.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/de6a2ca491eb20b2b669e732e84ce7af.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_TW.png":
/*!*******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_TW.png ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/83dd62c9b8fe57c2593672212bc09951.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c399212f9ed1df9720ff813360923865.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_TW.png":
/*!********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_TW.png ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4f9a17534c29f3e40970aa45d92f4ebb.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_TW.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_TW.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ddae2f39a0d6a932cc13b73a3464aaa5.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a998ad61ffc51ecd25cad7ef43a2d9f5.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_TW.png":
/*!*******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_TW.png ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/42115eaf3865efbbda1feaffc63c9a33.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_TW.png":
/*!******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_TW.png ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2b7f706af117e45b1f3717e929eba19e.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_TW.png":
/*!*********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_TW.png ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b395342091ad731257aeee0d6d03d19a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-flying-heart.zh_TW.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-flying-heart.zh_TW.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/44507755b21849685b8d585950b7a037.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-keep-score.zh_TW.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-keep-score.zh_TW.png ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c252c7ab1395a3a602cbcaeb19e6b928.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-make-interactive.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-make-interactive.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8de88e99a17d81538bdeb9fcac14b346.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-move-scenery.zh_TW.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-move-scenery.zh_TW.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4d9232fc24395ff39049820e215c9733.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-say-something.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-say-something.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/63b8962ea3c519d3b4fa7fb00a166f50.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-switch-costume.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-switch-costume.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d0658279229463ee5e53850f4cfea6d3.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_TW.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_TW.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8b7ad5c2d9787b3a9bad1458387cfff1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-point.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-point.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/40ca532104bc6d54c6c1e872ba571cfd.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/hide-show.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/hide-show.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d44a4ea3b3b168cf5212ee949f4f33d1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-change-costumes.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-change-costumes.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4b40b0a415a9776ae5413d1c6d7e63fc.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-choose-sound.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-choose-sound.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/870b8b39b077fc3423906a2e68b41245.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_TW.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_TW.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b494a3e0b00941252c2e1cdde6b17e42.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-fly-around.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-fly-around.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ebc2fa4e1e71773cc92275b58f140c39.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_TW.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_TW.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/60402ee4ea5c76b0d47183b82dcc1b1b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_TW.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_TW.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0288afb0be1ab93b1160026b13c8eb22.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-left-right.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-left-right.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/bfb4e4698a86df5f18d0bc345580142e.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_TW.gif":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_TW.gif ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2dda78968aae655c392d15281578a682.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_TW.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_TW.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a9dd1477f22d75060a8c3ef1fa06b3eb.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_TW.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_TW.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/36bc26581a9e802c2eec7be5f9de15b2.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-up-down.zh_TW.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-up-down.zh_TW.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f56033dd9db0150762c6acb792816ac9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-1-move.zh_TW.gif":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-1-move.zh_TW.gif ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7f848e761c790803ece92402ddc4a8d7.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-2-say.zh_TW.gif":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-2-say.zh_TW.gif ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8976ee64ef97be664426fa51a779489b.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-3-green-flag.zh_TW.gif":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-3-green-flag.zh_TW.gif ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ccfbf9a3edc4c5c792a2ae448d853e16.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_TW.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_TW.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0113ff98f5b42f42a53702f1e8db9499.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b5a010c5cfdd5526e177a8330beae1d5.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beat.zh_TW.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beat.zh_TW.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5d1ae91085a7e2014a3a09261ff0526b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beatbox.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beatbox.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1e975e828fa86a4b68f0c362c22207f3.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-song.zh_TW.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-song.zh_TW.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/01fe593f7d8bda9fedbe0e1eaee47740.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-play-sound.zh_TW.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-play-sound.zh_TW.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6891af6b9c97590c34cbbc234d66d24c.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-change-color.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-change-color.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b6b8630fa9df06dd65ac79d74298bc03.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-grow.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-grow.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/36b78bbefbadfa3a0557ec22c3fed5a6.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-play-sound.zh_TW.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-play-sound.zh_TW.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d925ccf215dcd4077e9e1a1f69a6dc81.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-spin.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-spin.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f7f46bfccd0339b382ebdc84d8245b1a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c6285665b5164fa3387b494bf5fa4fef.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-bounce-around.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-bounce-around.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d9ba5ee866df39f60291d55f77c4e331.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-choose-score.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-choose-score.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2b0d62e3a1bea98cc8b226ccee65e6a2.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-game-over.zh_TW.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-game-over.zh_TW.png ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7ce197172287887ac173f361ca360f02.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-insert-change-score.zh_TW.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-insert-change-score.zh_TW.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d57fa1b2d6cb01b2c7e55aacb679aa67.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2296a0aa7efc4539debb5ef94a56da61.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-reset-score.zh_TW.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-reset-score.zh_TW.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2cdfd14a17ab67ccda2e207b07d42672.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-color.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-color.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cec7826ea298dd0aed3a4c9cedaa3c71.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-score.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-score.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/84e7bba015155cafe943e83d54c0c4de.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-play-sound.zh_TW.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-play-sound.zh_TW.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2ffafb13c4cfe8ce811bbe1b4a0c2f94.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-random-position.zh_TW.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-random-position.zh_TW.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5f6162237b9164725d1a85b3a12b9a64.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-reset-score.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-reset-score.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c6a089bb8f98380b457b573b7ce4a187.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_TW.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_TW.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a933b8b20f7473854252589b22ed8319.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_TW.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_TW.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1bd7e4561286956370f8bcc27c43aa82.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_TW.png":
/*!********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_TW.png ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3e3698d8783d6f7d5350e53b9ad370b3.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_TW.png":
/*!************************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_TW.png ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3ec293692bbf3e8eb82f1e191c782ca4.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_TW.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_TW.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/fa1612f9c0474afcd38008ebc35cf735.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-add-extension.zh_TW.gif":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-add-extension.zh_TW.gif ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b77fe5cbd17bd82c89a19667e015cb4c.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-change-color.zh_TW.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-change-color.zh_TW.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/05f303cf5e0d682448fd86af2b820d27.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-grow-shrink.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-grow-shrink.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9f0eecc2f15f32ee8287decd10ef29a8.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-move-around.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-move-around.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c0933a65c76caab1d5d52bd21c1495e9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-say-something.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-say-something.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e8092ac373526cf01910e8be1c42b0d5.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-set-voice.zh_TW.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-set-voice.zh_TW.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/506c5a55f7956d6548af06160f800ecc.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-song.zh_TW.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-song.zh_TW.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4a11a91223cda9e4d997194afb7a580a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-spin.zh_TW.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-spin.zh_TW.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2fd9d2c7be81282708dc8e0951f8b221.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-point-in-direction.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-point-in-direction.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0c361253f627ef4566a25cdf5e8ae160.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-turn.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-turn.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/085c5eb3b205117750cc64925b74a284.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-conversation.zh_TW.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-conversation.zh_TW.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/578cb2e6df722f86b9fe84daa5e01e34.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-flip.zh_TW.gif":
/*!************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-flip.zh_TW.gif ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/227598e595f11ea77afb97fdc79b769c.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-hide-character.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-hide-character.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/da5eda28f6ce98ebf6c9ba47e5c52d50.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-say-something.zh_TW.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-say-something.zh_TW.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d290a2f6958b222711fb4d56966c3978.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-show-character.zh_TW.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-show-character.zh_TW.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b4b0b568e40b4296d473ed4906cb9fd7.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-switch-backdrop.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-switch-backdrop.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/75530645e4af177c82c6afff2bf3f7a8.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/switch-costumes.zh_TW.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/switch-costumes.zh_TW.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/75e825d30f294735fcc1468bd74cdb71.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_TW.gif":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_TW.gif ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/82e2890b48df96037aeb0e965cdd1cee.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_TW.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_TW.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/01a3b56eef292b43a137f9223b8a4934.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_TW.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_TW.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/576a1103506ec80bd274c7bc5f586a7e.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-3-say-something.zh_TW.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-3-say-something.zh_TW.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cf65c9399ffb51dfa464d282e3779b93.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_TW.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_TW.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ddc9fae77e4b0dc8e1b094f48d1c6e18.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-7-move-around.zh_TW.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-7-move-around.zh_TW.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0f52aaddde48ca7dfd58708fd379c5a1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-9-animate.zh_TW.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-9-animate.zh_TW.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/19ea1146c79e5305c5db33f5e1e78ef3.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-add-extension.zh_TW.gif":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-add-extension.zh_TW.gif ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d450e61af073265282cfdf43e7c61e96.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-animate.zh_TW.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-animate.zh_TW.png ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ff746430a87f7bc201d151b49ade12e6.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pet.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pet.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a7206ec49a3fb9b19a4067296f879553.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pop.zh_TW.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pop.zh_TW.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/fb5cf9e240a84ac8aa1e41a56e48701d.png";

/***/ }),

/***/ "./src/lib/libraries/decks/zh_TW-steps.js":
/*!************************************************!*\
  !*** ./src/lib/libraries/decks/zh_TW-steps.js ***!
  \************************************************/
/*! exports provided: zhTwImages */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zhTwImages", function() { return zhTwImages; });
/* harmony import */ var _steps_intro_1_move_zh_TW_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./steps/intro-1-move.zh_TW.gif */ "./src/lib/libraries/decks/steps/intro-1-move.zh_TW.gif");
/* harmony import */ var _steps_intro_1_move_zh_TW_gif__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_1_move_zh_TW_gif__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _steps_intro_2_say_zh_TW_gif__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./steps/intro-2-say.zh_TW.gif */ "./src/lib/libraries/decks/steps/intro-2-say.zh_TW.gif");
/* harmony import */ var _steps_intro_2_say_zh_TW_gif__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_2_say_zh_TW_gif__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _steps_intro_3_green_flag_zh_TW_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./steps/intro-3-green-flag.zh_TW.gif */ "./src/lib/libraries/decks/steps/intro-3-green-flag.zh_TW.gif");
/* harmony import */ var _steps_intro_3_green_flag_zh_TW_gif__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_3_green_flag_zh_TW_gif__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _steps_speech_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./steps/speech-add-extension.zh_TW.gif */ "./src/lib/libraries/decks/steps/speech-add-extension.zh_TW.gif");
/* harmony import */ var _steps_speech_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _steps_speech_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./steps/speech-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-say-something.zh_TW.png");
/* harmony import */ var _steps_speech_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _steps_speech_set_voice_zh_TW_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./steps/speech-set-voice.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-set-voice.zh_TW.png");
/* harmony import */ var _steps_speech_set_voice_zh_TW_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_set_voice_zh_TW_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _steps_speech_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./steps/speech-move-around.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-move-around.zh_TW.png");
/* harmony import */ var _steps_speech_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./steps/pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/pick-backdrop.LTR.gif");
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./steps/speech-add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/speech-add-sprite.LTR.gif");
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _steps_speech_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./steps/speech-song.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-song.zh_TW.png");
/* harmony import */ var _steps_speech_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _steps_speech_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./steps/speech-change-color.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-change-color.zh_TW.png");
/* harmony import */ var _steps_speech_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _steps_speech_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./steps/speech-spin.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-spin.zh_TW.png");
/* harmony import */ var _steps_speech_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _steps_speech_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./steps/speech-grow-shrink.zh_TW.png */ "./src/lib/libraries/decks/steps/speech-grow-shrink.zh_TW.png");
/* harmony import */ var _steps_speech_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./steps/cn-show-character.LTR.gif */ "./src/lib/libraries/decks/steps/cn-show-character.LTR.gif");
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _steps_cn_say_zh_TW_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./steps/cn-say.zh_TW.png */ "./src/lib/libraries/decks/steps/cn-say.zh_TW.png");
/* harmony import */ var _steps_cn_say_zh_TW_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_say_zh_TW_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _steps_cn_glide_zh_TW_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./steps/cn-glide.zh_TW.png */ "./src/lib/libraries/decks/steps/cn-glide.zh_TW.png");
/* harmony import */ var _steps_cn_glide_zh_TW_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_glide_zh_TW_png__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./steps/cn-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/cn-pick-sprite.LTR.gif");
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _steps_cn_collect_zh_TW_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./steps/cn-collect.zh_TW.png */ "./src/lib/libraries/decks/steps/cn-collect.zh_TW.png");
/* harmony import */ var _steps_cn_collect_zh_TW_png__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_collect_zh_TW_png__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./steps/add-variable.zh_TW.gif */ "./src/lib/libraries/decks/steps/add-variable.zh_TW.gif");
/* harmony import */ var _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _steps_cn_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./steps/cn-score.zh_TW.png */ "./src/lib/libraries/decks/steps/cn-score.zh_TW.png");
/* harmony import */ var _steps_cn_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _steps_cn_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./steps/cn-backdrop.zh_TW.png */ "./src/lib/libraries/decks/steps/cn-backdrop.zh_TW.png");
/* harmony import */ var _steps_cn_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./steps/add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/add-sprite.LTR.gif");
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./steps/name-pick-letter.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter.LTR.gif");
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _steps_name_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./steps/name-play-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/name-play-sound.zh_TW.png");
/* harmony import */ var _steps_name_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_steps_name_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./steps/name-pick-letter2.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter2.LTR.gif");
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _steps_name_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./steps/name-change-color.zh_TW.png */ "./src/lib/libraries/decks/steps/name-change-color.zh_TW.png");
/* harmony import */ var _steps_name_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_steps_name_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _steps_name_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./steps/name-spin.zh_TW.png */ "./src/lib/libraries/decks/steps/name-spin.zh_TW.png");
/* harmony import */ var _steps_name_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_steps_name_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _steps_name_grow_zh_TW_png__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./steps/name-grow.zh_TW.png */ "./src/lib/libraries/decks/steps/name-grow.zh_TW.png");
/* harmony import */ var _steps_name_grow_zh_TW_png__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_steps_name_grow_zh_TW_png__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./steps/music-pick-instrument.LTR.gif */ "./src/lib/libraries/decks/steps/music-pick-instrument.LTR.gif");
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _steps_music_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./steps/music-play-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/music-play-sound.zh_TW.png");
/* harmony import */ var _steps_music_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_steps_music_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _steps_music_make_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./steps/music-make-song.zh_TW.png */ "./src/lib/libraries/decks/steps/music-make-song.zh_TW.png");
/* harmony import */ var _steps_music_make_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _steps_music_make_beat_zh_TW_png__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./steps/music-make-beat.zh_TW.png */ "./src/lib/libraries/decks/steps/music-make-beat.zh_TW.png");
/* harmony import */ var _steps_music_make_beat_zh_TW_png__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beat_zh_TW_png__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _steps_music_make_beatbox_zh_TW_png__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./steps/music-make-beatbox.zh_TW.png */ "./src/lib/libraries/decks/steps/music-make-beatbox.zh_TW.png");
/* harmony import */ var _steps_music_make_beatbox_zh_TW_png__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beatbox_zh_TW_png__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./steps/chase-game-add-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-backdrop.LTR.gif");
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./steps/chase-game-add-sprite1.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite1.LTR.gif");
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _steps_chase_game_right_left_zh_TW_png__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./steps/chase-game-right-left.zh_TW.png */ "./src/lib/libraries/decks/steps/chase-game-right-left.zh_TW.png");
/* harmony import */ var _steps_chase_game_right_left_zh_TW_png__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_right_left_zh_TW_png__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _steps_chase_game_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./steps/chase-game-up-down.zh_TW.png */ "./src/lib/libraries/decks/steps/chase-game-up-down.zh_TW.png");
/* harmony import */ var _steps_chase_game_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./steps/chase-game-add-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite2.LTR.gif");
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _steps_chase_game_move_randomly_zh_TW_png__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./steps/chase-game-move-randomly.zh_TW.png */ "./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_TW.png");
/* harmony import */ var _steps_chase_game_move_randomly_zh_TW_png__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_move_randomly_zh_TW_png__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _steps_chase_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./steps/chase-game-play-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/chase-game-play-sound.zh_TW.png");
/* harmony import */ var _steps_chase_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _steps_chase_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./steps/chase-game-change-score.zh_TW.png */ "./src/lib/libraries/decks/steps/chase-game-change-score.zh_TW.png");
/* harmony import */ var _steps_chase_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./steps/pop-game-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/pop-game-pick-sprite.LTR.gif");
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _steps_pop_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./steps/pop-game-play-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/pop-game-play-sound.zh_TW.png");
/* harmony import */ var _steps_pop_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _steps_pop_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./steps/pop-game-change-score.zh_TW.png */ "./src/lib/libraries/decks/steps/pop-game-change-score.zh_TW.png");
/* harmony import */ var _steps_pop_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _steps_pop_game_random_position_zh_TW_png__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./steps/pop-game-random-position.zh_TW.png */ "./src/lib/libraries/decks/steps/pop-game-random-position.zh_TW.png");
/* harmony import */ var _steps_pop_game_random_position_zh_TW_png__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_random_position_zh_TW_png__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var _steps_pop_game_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./steps/pop-game-change-color.zh_TW.png */ "./src/lib/libraries/decks/steps/pop-game-change-color.zh_TW.png");
/* harmony import */ var _steps_pop_game_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var _steps_pop_game_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./steps/pop-game-reset-score.zh_TW.png */ "./src/lib/libraries/decks/steps/pop-game-reset-score.zh_TW.png");
/* harmony import */ var _steps_pop_game_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./steps/animate-char-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/animate-char-pick-sprite.LTR.gif");
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var _steps_animate_char_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./steps/animate-char-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-say-something.zh_TW.png");
/* harmony import */ var _steps_animate_char_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var _steps_animate_char_add_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./steps/animate-char-add-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-add-sound.zh_TW.png");
/* harmony import */ var _steps_animate_char_add_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_add_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var _steps_animate_char_talk_zh_TW_png__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./steps/animate-char-talk.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-talk.zh_TW.png");
/* harmony import */ var _steps_animate_char_talk_zh_TW_png__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_talk_zh_TW_png__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var _steps_animate_char_move_zh_TW_png__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./steps/animate-char-move.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-move.zh_TW.png");
/* harmony import */ var _steps_animate_char_move_zh_TW_png__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_move_zh_TW_png__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var _steps_animate_char_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./steps/animate-char-jump.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-jump.zh_TW.png");
/* harmony import */ var _steps_animate_char_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var _steps_animate_char_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./steps/animate-char-change-color.zh_TW.png */ "./src/lib/libraries/decks/steps/animate-char-change-color.zh_TW.png");
/* harmony import */ var _steps_animate_char_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./steps/story-pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop.LTR.gif");
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./steps/story-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite.LTR.gif");
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var _steps_story_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./steps/story-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/story-say-something.zh_TW.png");
/* harmony import */ var _steps_story_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(_steps_story_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./steps/story-pick-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite2.LTR.gif");
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var _steps_story_flip_zh_TW_gif__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./steps/story-flip.zh_TW.gif */ "./src/lib/libraries/decks/steps/story-flip.zh_TW.gif");
/* harmony import */ var _steps_story_flip_zh_TW_gif__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(_steps_story_flip_zh_TW_gif__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var _steps_story_conversation_zh_TW_png__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./steps/story-conversation.zh_TW.png */ "./src/lib/libraries/decks/steps/story-conversation.zh_TW.png");
/* harmony import */ var _steps_story_conversation_zh_TW_png__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(_steps_story_conversation_zh_TW_png__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ./steps/story-pick-backdrop2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop2.LTR.gif");
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var _steps_story_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ./steps/story-switch-backdrop.zh_TW.png */ "./src/lib/libraries/decks/steps/story-switch-backdrop.zh_TW.png");
/* harmony import */ var _steps_story_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(_steps_story_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var _steps_story_hide_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ./steps/story-hide-character.zh_TW.png */ "./src/lib/libraries/decks/steps/story-hide-character.zh_TW.png");
/* harmony import */ var _steps_story_hide_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(_steps_story_hide_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var _steps_story_show_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ./steps/story-show-character.zh_TW.png */ "./src/lib/libraries/decks/steps/story-show-character.zh_TW.png");
/* harmony import */ var _steps_story_show_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(_steps_story_show_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var _steps_video_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! ./steps/video-add-extension.zh_TW.gif */ "./src/lib/libraries/decks/steps/video-add-extension.zh_TW.gif");
/* harmony import */ var _steps_video_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(_steps_video_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var _steps_video_pet_zh_TW_png__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! ./steps/video-pet.zh_TW.png */ "./src/lib/libraries/decks/steps/video-pet.zh_TW.png");
/* harmony import */ var _steps_video_pet_zh_TW_png__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pet_zh_TW_png__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var _steps_video_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! ./steps/video-animate.zh_TW.png */ "./src/lib/libraries/decks/steps/video-animate.zh_TW.png");
/* harmony import */ var _steps_video_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(_steps_video_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var _steps_video_pop_zh_TW_png__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! ./steps/video-pop.zh_TW.png */ "./src/lib/libraries/decks/steps/video-pop.zh_TW.png");
/* harmony import */ var _steps_video_pop_zh_TW_png__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pop_zh_TW_png__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(/*! ./steps/fly-choose-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-backdrop.LTR.gif");
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(/*! ./steps/fly-choose-character.LTR.png */ "./src/lib/libraries/decks/steps/fly-choose-character.LTR.png");
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var _steps_fly_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(/*! ./steps/fly-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-say-something.zh_TW.png");
/* harmony import */ var _steps_fly_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var _steps_fly_make_interactive_zh_TW_png__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(/*! ./steps/fly-make-interactive.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-make-interactive.zh_TW.png");
/* harmony import */ var _steps_fly_make_interactive_zh_TW_png__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_make_interactive_zh_TW_png__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(/*! ./steps/fly-object-to-collect.LTR.png */ "./src/lib/libraries/decks/steps/fly-object-to-collect.LTR.png");
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var _steps_fly_flying_heart_zh_TW_png__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(/*! ./steps/fly-flying-heart.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-flying-heart.zh_TW.png");
/* harmony import */ var _steps_fly_flying_heart_zh_TW_png__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_flying_heart_zh_TW_png__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(/*! ./steps/fly-select-flyer.LTR.png */ "./src/lib/libraries/decks/steps/fly-select-flyer.LTR.png");
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var _steps_fly_keep_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(/*! ./steps/fly-keep-score.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-keep-score.zh_TW.png");
/* harmony import */ var _steps_fly_keep_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_keep_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(/*! ./steps/fly-choose-scenery.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-scenery.LTR.gif");
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var _steps_fly_move_scenery_zh_TW_png__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(/*! ./steps/fly-move-scenery.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-move-scenery.zh_TW.png");
/* harmony import */ var _steps_fly_move_scenery_zh_TW_png__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_move_scenery_zh_TW_png__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var _steps_fly_switch_costume_zh_TW_png__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(/*! ./steps/fly-switch-costume.zh_TW.png */ "./src/lib/libraries/decks/steps/fly-switch-costume.zh_TW.png");
/* harmony import */ var _steps_fly_switch_costume_zh_TW_png__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_switch_costume_zh_TW_png__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(/*! ./steps/pong-add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-backdrop.LTR.png");
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(/*! ./steps/pong-add-ball-sprite.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-ball-sprite.LTR.png");
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__);
/* harmony import */ var _steps_pong_bounce_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(/*! ./steps/pong-bounce-around.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-bounce-around.zh_TW.png");
/* harmony import */ var _steps_pong_bounce_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_81___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_bounce_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_81__);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(/*! ./steps/pong-add-a-paddle.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-a-paddle.LTR.gif");
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__);
/* harmony import */ var _steps_pong_move_the_paddle_zh_TW_png__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(/*! ./steps/pong-move-the-paddle.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_TW.png");
/* harmony import */ var _steps_pong_move_the_paddle_zh_TW_png__WEBPACK_IMPORTED_MODULE_83___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_move_the_paddle_zh_TW_png__WEBPACK_IMPORTED_MODULE_83__);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(/*! ./steps/pong-select-ball.LTR.png */ "./src/lib/libraries/decks/steps/pong-select-ball.LTR.png");
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__);
/* harmony import */ var _steps_pong_add_code_to_ball_zh_TW_png__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(/*! ./steps/pong-add-code-to-ball.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_TW.png");
/* harmony import */ var _steps_pong_add_code_to_ball_zh_TW_png__WEBPACK_IMPORTED_MODULE_85___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_code_to_ball_zh_TW_png__WEBPACK_IMPORTED_MODULE_85__);
/* harmony import */ var _steps_pong_choose_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(/*! ./steps/pong-choose-score.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-choose-score.zh_TW.png");
/* harmony import */ var _steps_pong_choose_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_86___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_choose_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_86__);
/* harmony import */ var _steps_pong_insert_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(/*! ./steps/pong-insert-change-score.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-insert-change-score.zh_TW.png");
/* harmony import */ var _steps_pong_insert_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_87___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_insert_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_87__);
/* harmony import */ var _steps_pong_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(/*! ./steps/pong-reset-score.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-reset-score.zh_TW.png");
/* harmony import */ var _steps_pong_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_88___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_88__);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(/*! ./steps/pong-add-line.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-line.LTR.gif");
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__);
/* harmony import */ var _steps_pong_game_over_zh_TW_png__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(/*! ./steps/pong-game-over.zh_TW.png */ "./src/lib/libraries/decks/steps/pong-game-over.zh_TW.png");
/* harmony import */ var _steps_pong_game_over_zh_TW_png__WEBPACK_IMPORTED_MODULE_90___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_game_over_zh_TW_png__WEBPACK_IMPORTED_MODULE_90__);
/* harmony import */ var _steps_imagine_type_what_you_want_zh_TW_png__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(/*! ./steps/imagine-type-what-you-want.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_TW.png");
/* harmony import */ var _steps_imagine_type_what_you_want_zh_TW_png__WEBPACK_IMPORTED_MODULE_91___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_type_what_you_want_zh_TW_png__WEBPACK_IMPORTED_MODULE_91__);
/* harmony import */ var _steps_imagine_click_green_flag_zh_TW_png__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(/*! ./steps/imagine-click-green-flag.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_TW.png");
/* harmony import */ var _steps_imagine_click_green_flag_zh_TW_png__WEBPACK_IMPORTED_MODULE_92___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_click_green_flag_zh_TW_png__WEBPACK_IMPORTED_MODULE_92__);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(/*! ./steps/imagine-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(/*! ./steps/imagine-choose-any-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-any-sprite.LTR.png");
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__);
/* harmony import */ var _steps_imagine_fly_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(/*! ./steps/imagine-fly-around.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-fly-around.zh_TW.png");
/* harmony import */ var _steps_imagine_fly_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_95___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_fly_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_95__);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(/*! ./steps/imagine-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__);
/* harmony import */ var _steps_imagine_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(/*! ./steps/imagine-left-right.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-left-right.zh_TW.png");
/* harmony import */ var _steps_imagine_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_97___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_97__);
/* harmony import */ var _steps_imagine_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(/*! ./steps/imagine-up-down.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-up-down.zh_TW.png");
/* harmony import */ var _steps_imagine_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_98___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_98__);
/* harmony import */ var _steps_imagine_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(/*! ./steps/imagine-change-costumes.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-change-costumes.zh_TW.png");
/* harmony import */ var _steps_imagine_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_99___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_99__);
/* harmony import */ var _steps_imagine_glide_to_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(/*! ./steps/imagine-glide-to-point.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_TW.png");
/* harmony import */ var _steps_imagine_glide_to_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_100___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_glide_to_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_100__);
/* harmony import */ var _steps_imagine_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(/*! ./steps/imagine-grow-shrink.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_TW.png");
/* harmony import */ var _steps_imagine_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_101___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_101__);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(/*! ./steps/imagine-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__);
/* harmony import */ var _steps_imagine_switch_backdrops_zh_TW_png__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(/*! ./steps/imagine-switch-backdrops.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_TW.png");
/* harmony import */ var _steps_imagine_switch_backdrops_zh_TW_png__WEBPACK_IMPORTED_MODULE_103___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_switch_backdrops_zh_TW_png__WEBPACK_IMPORTED_MODULE_103__);
/* harmony import */ var _steps_imagine_record_a_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(/*! ./steps/imagine-record-a-sound.zh_TW.gif */ "./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_TW.gif");
/* harmony import */ var _steps_imagine_record_a_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_104___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_record_a_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_104__);
/* harmony import */ var _steps_imagine_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(/*! ./steps/imagine-choose-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/imagine-choose-sound.zh_TW.png");
/* harmony import */ var _steps_imagine_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_105___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_105__);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(/*! ./steps/add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/add-backdrop.LTR.png");
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default = /*#__PURE__*/__webpack_require__.n(_steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__);
/* harmony import */ var _steps_add_effects_zh_TW_png__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(/*! ./steps/add-effects.zh_TW.png */ "./src/lib/libraries/decks/steps/add-effects.zh_TW.png");
/* harmony import */ var _steps_add_effects_zh_TW_png__WEBPACK_IMPORTED_MODULE_107___default = /*#__PURE__*/__webpack_require__.n(_steps_add_effects_zh_TW_png__WEBPACK_IMPORTED_MODULE_107__);
/* harmony import */ var _steps_hide_show_zh_TW_png__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(/*! ./steps/hide-show.zh_TW.png */ "./src/lib/libraries/decks/steps/hide-show.zh_TW.png");
/* harmony import */ var _steps_hide_show_zh_TW_png__WEBPACK_IMPORTED_MODULE_108___default = /*#__PURE__*/__webpack_require__.n(_steps_hide_show_zh_TW_png__WEBPACK_IMPORTED_MODULE_108__);
/* harmony import */ var _steps_switch_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(/*! ./steps/switch-costumes.zh_TW.png */ "./src/lib/libraries/decks/steps/switch-costumes.zh_TW.png");
/* harmony import */ var _steps_switch_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_109___default = /*#__PURE__*/__webpack_require__.n(_steps_switch_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_109__);
/* harmony import */ var _steps_change_size_zh_TW_png__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(/*! ./steps/change-size.zh_TW.png */ "./src/lib/libraries/decks/steps/change-size.zh_TW.png");
/* harmony import */ var _steps_change_size_zh_TW_png__WEBPACK_IMPORTED_MODULE_110___default = /*#__PURE__*/__webpack_require__.n(_steps_change_size_zh_TW_png__WEBPACK_IMPORTED_MODULE_110__);
/* harmony import */ var _steps_spin_turn_zh_TW_png__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(/*! ./steps/spin-turn.zh_TW.png */ "./src/lib/libraries/decks/steps/spin-turn.zh_TW.png");
/* harmony import */ var _steps_spin_turn_zh_TW_png__WEBPACK_IMPORTED_MODULE_111___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_turn_zh_TW_png__WEBPACK_IMPORTED_MODULE_111__);
/* harmony import */ var _steps_spin_point_in_direction_zh_TW_png__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(/*! ./steps/spin-point-in-direction.zh_TW.png */ "./src/lib/libraries/decks/steps/spin-point-in-direction.zh_TW.png");
/* harmony import */ var _steps_spin_point_in_direction_zh_TW_png__WEBPACK_IMPORTED_MODULE_112___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_point_in_direction_zh_TW_png__WEBPACK_IMPORTED_MODULE_112__);
/* harmony import */ var _steps_record_a_sound_sounds_tab_zh_TW_png__WEBPACK_IMPORTED_MODULE_113__ = __webpack_require__(/*! ./steps/record-a-sound-sounds-tab.zh_TW.png */ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_TW.png");
/* harmony import */ var _steps_record_a_sound_sounds_tab_zh_TW_png__WEBPACK_IMPORTED_MODULE_113___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_sounds_tab_zh_TW_png__WEBPACK_IMPORTED_MODULE_113__);
/* harmony import */ var _steps_record_a_sound_click_record_zh_TW_png__WEBPACK_IMPORTED_MODULE_114__ = __webpack_require__(/*! ./steps/record-a-sound-click-record.zh_TW.png */ "./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_TW.png");
/* harmony import */ var _steps_record_a_sound_click_record_zh_TW_png__WEBPACK_IMPORTED_MODULE_114___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_click_record_zh_TW_png__WEBPACK_IMPORTED_MODULE_114__);
/* harmony import */ var _steps_record_a_sound_press_record_button_zh_TW_png__WEBPACK_IMPORTED_MODULE_115__ = __webpack_require__(/*! ./steps/record-a-sound-press-record-button.zh_TW.png */ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_TW.png");
/* harmony import */ var _steps_record_a_sound_press_record_button_zh_TW_png__WEBPACK_IMPORTED_MODULE_115___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_press_record_button_zh_TW_png__WEBPACK_IMPORTED_MODULE_115__);
/* harmony import */ var _steps_record_a_sound_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_116__ = __webpack_require__(/*! ./steps/record-a-sound-choose-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_TW.png");
/* harmony import */ var _steps_record_a_sound_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_116___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_116__);
/* harmony import */ var _steps_record_a_sound_play_your_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_117__ = __webpack_require__(/*! ./steps/record-a-sound-play-your-sound.zh_TW.png */ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_TW.png");
/* harmony import */ var _steps_record_a_sound_play_your_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_117___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_play_your_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_117__);
/* harmony import */ var _steps_move_arrow_keys_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_118__ = __webpack_require__(/*! ./steps/move-arrow-keys-left-right.zh_TW.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_TW.png");
/* harmony import */ var _steps_move_arrow_keys_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_118___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_118__);
/* harmony import */ var _steps_move_arrow_keys_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_119__ = __webpack_require__(/*! ./steps/move-arrow-keys-up-down.zh_TW.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_TW.png");
/* harmony import */ var _steps_move_arrow_keys_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_119___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_119__);
/* harmony import */ var _steps_glide_around_back_and_forth_zh_TW_png__WEBPACK_IMPORTED_MODULE_120__ = __webpack_require__(/*! ./steps/glide-around-back-and-forth.zh_TW.png */ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_TW.png");
/* harmony import */ var _steps_glide_around_back_and_forth_zh_TW_png__WEBPACK_IMPORTED_MODULE_120___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_back_and_forth_zh_TW_png__WEBPACK_IMPORTED_MODULE_120__);
/* harmony import */ var _steps_glide_around_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_121__ = __webpack_require__(/*! ./steps/glide-around-point.zh_TW.png */ "./src/lib/libraries/decks/steps/glide-around-point.zh_TW.png");
/* harmony import */ var _steps_glide_around_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_121___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_121__);
/* harmony import */ var _steps_code_cartoon_01_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_122__ = __webpack_require__(/*! ./steps/code-cartoon-01-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_01_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_122___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_01_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_122__);
/* harmony import */ var _steps_code_cartoon_02_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_123__ = __webpack_require__(/*! ./steps/code-cartoon-02-animate.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_02_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_123___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_02_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_123__);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__ = __webpack_require__(/*! ./steps/code-cartoon-03-select-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-03-select-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_zh_TW_png__WEBPACK_IMPORTED_MODULE_125__ = __webpack_require__(/*! ./steps/code-cartoon-04-use-minus-sign.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_zh_TW_png__WEBPACK_IMPORTED_MODULE_125___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_04_use_minus_sign_zh_TW_png__WEBPACK_IMPORTED_MODULE_125__);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_126__ = __webpack_require__(/*! ./steps/code-cartoon-05-grow-shrink.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_126___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_05_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_126__);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__ = __webpack_require__(/*! ./steps/code-cartoon-06-select-another-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-06-select-another-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__);
/* harmony import */ var _steps_code_cartoon_07_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_128__ = __webpack_require__(/*! ./steps/code-cartoon-07-jump.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_07_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_128___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_07_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_128__);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_zh_TW_png__WEBPACK_IMPORTED_MODULE_129__ = __webpack_require__(/*! ./steps/code-cartoon-08-change-scenes.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_08_change_scenes_zh_TW_png__WEBPACK_IMPORTED_MODULE_129___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_08_change_scenes_zh_TW_png__WEBPACK_IMPORTED_MODULE_129__);
/* harmony import */ var _steps_code_cartoon_09_glide_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_130__ = __webpack_require__(/*! ./steps/code-cartoon-09-glide-around.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_09_glide_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_130___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_09_glide_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_130__);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_131__ = __webpack_require__(/*! ./steps/code-cartoon-10-change-costumes.zh_TW.png */ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_TW.png");
/* harmony import */ var _steps_code_cartoon_10_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_131___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_10_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_131__);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__ = __webpack_require__(/*! ./steps/code-cartoon-11-choose-more-characters.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-11-choose-more-characters.LTR.png");
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__ = __webpack_require__(/*! ./steps/talking-2-choose-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-2-choose-sprite.LTR.png");
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__);
/* harmony import */ var _steps_talking_3_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_134__ = __webpack_require__(/*! ./steps/talking-3-say-something.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-3-say-something.zh_TW.png");
/* harmony import */ var _steps_talking_3_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_134___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_3_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_134__);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__ = __webpack_require__(/*! ./steps/talking-4-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-4-choose-backdrop.LTR.png");
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__);
/* harmony import */ var _steps_talking_5_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_136__ = __webpack_require__(/*! ./steps/talking-5-switch-backdrop.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_TW.png");
/* harmony import */ var _steps_talking_5_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_136___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_5_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_136__);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__ = __webpack_require__(/*! ./steps/talking-6-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-6-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__);
/* harmony import */ var _steps_talking_7_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_138__ = __webpack_require__(/*! ./steps/talking-7-move-around.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-7-move-around.zh_TW.png");
/* harmony import */ var _steps_talking_7_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_138___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_7_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_138__);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__ = __webpack_require__(/*! ./steps/talking-8-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-8-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__);
/* harmony import */ var _steps_talking_9_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_140__ = __webpack_require__(/*! ./steps/talking-9-animate.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-9-animate.zh_TW.png");
/* harmony import */ var _steps_talking_9_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_140___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_9_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_140__);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__ = __webpack_require__(/*! ./steps/talking-10-choose-third-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-10-choose-third-backdrop.LTR.png");
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__);
/* harmony import */ var _steps_talking_11_choose_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_142__ = __webpack_require__(/*! ./steps/talking-11-choose-sound.zh_TW.gif */ "./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_TW.gif");
/* harmony import */ var _steps_talking_11_choose_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_142___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_11_choose_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_142__);
/* harmony import */ var _steps_talking_12_dance_moves_zh_TW_png__WEBPACK_IMPORTED_MODULE_143__ = __webpack_require__(/*! ./steps/talking-12-dance-moves.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_TW.png");
/* harmony import */ var _steps_talking_12_dance_moves_zh_TW_png__WEBPACK_IMPORTED_MODULE_143___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_12_dance_moves_zh_TW_png__WEBPACK_IMPORTED_MODULE_143__);
/* harmony import */ var _steps_talking_13_ask_and_answer_zh_TW_png__WEBPACK_IMPORTED_MODULE_144__ = __webpack_require__(/*! ./steps/talking-13-ask-and-answer.zh_TW.png */ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_TW.png");
/* harmony import */ var _steps_talking_13_ask_and_answer_zh_TW_png__WEBPACK_IMPORTED_MODULE_144___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_13_ask_and_answer_zh_TW_png__WEBPACK_IMPORTED_MODULE_144__);
// Intro




// Text to Speech











// Cartoon Network









// Add sprite


// Animate a name







// Make Music






// Chase-Game










// Clicker-Game (Pop Game)








// Animate A Character









// Tell A Story











// Video Sensing





// Make it Fly













// Pong














// Imagine a World
















// Add a Backdrop


// Add Effects


// Hide and Show


// Switch Costumes


// Change Size


// Spin



// Record a Sound






// Use Arrow Keys



// Glide Around



// Code a Cartoon












// Talking Tales













var zhTwImages = {
  // Intro
  introMove: _steps_intro_1_move_zh_TW_gif__WEBPACK_IMPORTED_MODULE_0___default.a,
  introSay: _steps_intro_2_say_zh_TW_gif__WEBPACK_IMPORTED_MODULE_1___default.a,
  introGreenFlag: _steps_intro_3_green_flag_zh_TW_gif__WEBPACK_IMPORTED_MODULE_2___default.a,
  // Text to Speech
  speechAddExtension: _steps_speech_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  speechSaySomething: _steps_speech_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  speechSetVoice: _steps_speech_set_voice_zh_TW_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  speechMoveAround: _steps_speech_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  speechAddBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  speechAddSprite: _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default.a,
  speechSong: _steps_speech_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_9___default.a,
  speechChangeColor: _steps_speech_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_10___default.a,
  speechSpin: _steps_speech_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_11___default.a,
  speechGrowShrink: _steps_speech_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_12___default.a,
  // Cartoon Network
  cnShowCharacter: _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default.a,
  cnSay: _steps_cn_say_zh_TW_png__WEBPACK_IMPORTED_MODULE_14___default.a,
  cnGlide: _steps_cn_glide_zh_TW_png__WEBPACK_IMPORTED_MODULE_15___default.a,
  cnPickSprite: _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default.a,
  cnCollect: _steps_cn_collect_zh_TW_png__WEBPACK_IMPORTED_MODULE_17___default.a,
  cnVariable: _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  cnScore: _steps_cn_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_19___default.a,
  cnBackdrop: _steps_cn_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_20___default.a,
  // Add sprite
  addSprite: _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default.a,
  // Animate a name
  namePickLetter: _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default.a,
  namePlaySound: _steps_name_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_23___default.a,
  namePickLetter2: _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default.a,
  nameChangeColor: _steps_name_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_25___default.a,
  nameSpin: _steps_name_spin_zh_TW_png__WEBPACK_IMPORTED_MODULE_26___default.a,
  nameGrow: _steps_name_grow_zh_TW_png__WEBPACK_IMPORTED_MODULE_27___default.a,
  // Make-Music
  musicPickInstrument: _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default.a,
  musicPlaySound: _steps_music_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_29___default.a,
  musicMakeSong: _steps_music_make_song_zh_TW_png__WEBPACK_IMPORTED_MODULE_30___default.a,
  musicMakeBeat: _steps_music_make_beat_zh_TW_png__WEBPACK_IMPORTED_MODULE_31___default.a,
  musicMakeBeatbox: _steps_music_make_beatbox_zh_TW_png__WEBPACK_IMPORTED_MODULE_32___default.a,
  // Chase-Game
  chaseGameAddBackdrop: _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default.a,
  chaseGameAddSprite1: _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default.a,
  chaseGameRightLeft: _steps_chase_game_right_left_zh_TW_png__WEBPACK_IMPORTED_MODULE_35___default.a,
  chaseGameUpDown: _steps_chase_game_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_36___default.a,
  chaseGameAddSprite2: _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default.a,
  chaseGameMoveRandomly: _steps_chase_game_move_randomly_zh_TW_png__WEBPACK_IMPORTED_MODULE_38___default.a,
  chaseGamePlaySound: _steps_chase_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_39___default.a,
  chaseGameAddVariable: _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  chaseGameChangeScore: _steps_chase_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_40___default.a,
  // Make-A-Pop/Clicker Game
  popGamePickSprite: _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default.a,
  popGamePlaySound: _steps_pop_game_play_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_42___default.a,
  popGameAddScore: _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  popGameChangeScore: _steps_pop_game_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_43___default.a,
  popGameRandomPosition: _steps_pop_game_random_position_zh_TW_png__WEBPACK_IMPORTED_MODULE_44___default.a,
  popGameChangeColor: _steps_pop_game_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_45___default.a,
  popGameResetScore: _steps_pop_game_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_46___default.a,
  // Animate A Character
  animateCharPickBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  animateCharPickSprite: _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default.a,
  animateCharSaySomething: _steps_animate_char_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_48___default.a,
  animateCharAddSound: _steps_animate_char_add_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_49___default.a,
  animateCharTalk: _steps_animate_char_talk_zh_TW_png__WEBPACK_IMPORTED_MODULE_50___default.a,
  animateCharMove: _steps_animate_char_move_zh_TW_png__WEBPACK_IMPORTED_MODULE_51___default.a,
  animateCharJump: _steps_animate_char_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_52___default.a,
  animateCharChangeColor: _steps_animate_char_change_color_zh_TW_png__WEBPACK_IMPORTED_MODULE_53___default.a,
  // Tell A Story
  storyPickBackdrop: _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default.a,
  storyPickSprite: _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default.a,
  storySaySomething: _steps_story_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_56___default.a,
  storyPickSprite2: _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default.a,
  storyFlip: _steps_story_flip_zh_TW_gif__WEBPACK_IMPORTED_MODULE_58___default.a,
  storyConversation: _steps_story_conversation_zh_TW_png__WEBPACK_IMPORTED_MODULE_59___default.a,
  storyPickBackdrop2: _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default.a,
  storySwitchBackdrop: _steps_story_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_61___default.a,
  storyHideCharacter: _steps_story_hide_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_62___default.a,
  storyShowCharacter: _steps_story_show_character_zh_TW_png__WEBPACK_IMPORTED_MODULE_63___default.a,
  // Video Sensing
  videoAddExtension: _steps_video_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_64___default.a,
  videoPet: _steps_video_pet_zh_TW_png__WEBPACK_IMPORTED_MODULE_65___default.a,
  videoAnimate: _steps_video_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_66___default.a,
  videoPop: _steps_video_pop_zh_TW_png__WEBPACK_IMPORTED_MODULE_67___default.a,
  // Make it Fly
  flyChooseBackdrop: _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default.a,
  flyChooseCharacter: _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default.a,
  flySaySomething: _steps_fly_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_70___default.a,
  flyMoveArrows: _steps_fly_make_interactive_zh_TW_png__WEBPACK_IMPORTED_MODULE_71___default.a,
  flyChooseObject: _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default.a,
  flyFlyingObject: _steps_fly_flying_heart_zh_TW_png__WEBPACK_IMPORTED_MODULE_73___default.a,
  flySelectFlyingSprite: _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default.a,
  flyAddScore: _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  flyKeepScore: _steps_fly_keep_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_75___default.a,
  flyAddScenery: _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default.a,
  flyMoveScenery: _steps_fly_move_scenery_zh_TW_png__WEBPACK_IMPORTED_MODULE_77___default.a,
  flySwitchLooks: _steps_fly_switch_costume_zh_TW_png__WEBPACK_IMPORTED_MODULE_78___default.a,
  // Pong
  pongAddBackdrop: _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default.a,
  pongAddBallSprite: _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default.a,
  pongBounceAround: _steps_pong_bounce_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_81___default.a,
  pongAddPaddle: _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default.a,
  pongMoveThePaddle: _steps_pong_move_the_paddle_zh_TW_png__WEBPACK_IMPORTED_MODULE_83___default.a,
  pongSelectBallSprite: _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default.a,
  pongAddMoreCodeToBall: _steps_pong_add_code_to_ball_zh_TW_png__WEBPACK_IMPORTED_MODULE_85___default.a,
  pongAddAScore: _steps_add_variable_zh_TW_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  pongChooseScoreFromMenu: _steps_pong_choose_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_86___default.a,
  pongInsertChangeScoreBlock: _steps_pong_insert_change_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_87___default.a,
  pongResetScore: _steps_pong_reset_score_zh_TW_png__WEBPACK_IMPORTED_MODULE_88___default.a,
  pongAddLineSprite: _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default.a,
  pongGameOver: _steps_pong_game_over_zh_TW_png__WEBPACK_IMPORTED_MODULE_90___default.a,
  // Imagine a World
  imagineTypeWhatYouWant: _steps_imagine_type_what_you_want_zh_TW_png__WEBPACK_IMPORTED_MODULE_91___default.a,
  imagineClickGreenFlag: _steps_imagine_click_green_flag_zh_TW_png__WEBPACK_IMPORTED_MODULE_92___default.a,
  imagineChooseBackdrop: _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default.a,
  imagineChooseSprite: _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default.a,
  imagineFlyAround: _steps_imagine_fly_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_95___default.a,
  imagineChooseAnotherSprite: _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default.a,
  imagineLeftRight: _steps_imagine_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_97___default.a,
  imagineUpDown: _steps_imagine_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_98___default.a,
  imagineChangeCostumes: _steps_imagine_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_99___default.a,
  imagineGlideToPoint: _steps_imagine_glide_to_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_100___default.a,
  imagineGrowShrink: _steps_imagine_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_101___default.a,
  imagineChooseAnotherBackdrop: _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default.a,
  imagineSwitchBackdrops: _steps_imagine_switch_backdrops_zh_TW_png__WEBPACK_IMPORTED_MODULE_103___default.a,
  imagineRecordASound: _steps_imagine_record_a_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_104___default.a,
  imagineChooseSound: _steps_imagine_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_105___default.a,
  // Add a Backdrop
  addBackdrop: _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default.a,
  // Add Effects
  addEffects: _steps_add_effects_zh_TW_png__WEBPACK_IMPORTED_MODULE_107___default.a,
  // Hide and Show
  hideAndShow: _steps_hide_show_zh_TW_png__WEBPACK_IMPORTED_MODULE_108___default.a,
  // Switch Costumes
  switchCostumes: _steps_switch_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_109___default.a,
  // Change Size
  changeSize: _steps_change_size_zh_TW_png__WEBPACK_IMPORTED_MODULE_110___default.a,
  // Spin
  spinTurn: _steps_spin_turn_zh_TW_png__WEBPACK_IMPORTED_MODULE_111___default.a,
  spinPointInDirection: _steps_spin_point_in_direction_zh_TW_png__WEBPACK_IMPORTED_MODULE_112___default.a,
  // Record a Sound
  recordASoundSoundsTab: _steps_record_a_sound_sounds_tab_zh_TW_png__WEBPACK_IMPORTED_MODULE_113___default.a,
  recordASoundClickRecord: _steps_record_a_sound_click_record_zh_TW_png__WEBPACK_IMPORTED_MODULE_114___default.a,
  recordASoundPressRecordButton: _steps_record_a_sound_press_record_button_zh_TW_png__WEBPACK_IMPORTED_MODULE_115___default.a,
  recordASoundChooseSound: _steps_record_a_sound_choose_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_116___default.a,
  recordASoundPlayYourSound: _steps_record_a_sound_play_your_sound_zh_TW_png__WEBPACK_IMPORTED_MODULE_117___default.a,
  // Use Arrow Keys
  moveArrowKeysLeftRight: _steps_move_arrow_keys_left_right_zh_TW_png__WEBPACK_IMPORTED_MODULE_118___default.a,
  moveArrowKeysUpDown: _steps_move_arrow_keys_up_down_zh_TW_png__WEBPACK_IMPORTED_MODULE_119___default.a,
  // Glide Around
  glideAroundBackAndForth: _steps_glide_around_back_and_forth_zh_TW_png__WEBPACK_IMPORTED_MODULE_120___default.a,
  glideAroundPoint: _steps_glide_around_point_zh_TW_png__WEBPACK_IMPORTED_MODULE_121___default.a,
  // Code a Cartoon
  codeCartoonSaySomething: _steps_code_cartoon_01_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_122___default.a,
  codeCartoonAnimate: _steps_code_cartoon_02_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_123___default.a,
  codeCartoonSelectDifferentCharacter: _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default.a,
  codeCartoonUseMinusSign: _steps_code_cartoon_04_use_minus_sign_zh_TW_png__WEBPACK_IMPORTED_MODULE_125___default.a,
  codeCartoonGrowShrink: _steps_code_cartoon_05_grow_shrink_zh_TW_png__WEBPACK_IMPORTED_MODULE_126___default.a,
  codeCartoonSelectDifferentCharacter2: _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default.a,
  codeCartoonJump: _steps_code_cartoon_07_jump_zh_TW_png__WEBPACK_IMPORTED_MODULE_128___default.a,
  codeCartoonChangeScenes: _steps_code_cartoon_08_change_scenes_zh_TW_png__WEBPACK_IMPORTED_MODULE_129___default.a,
  codeCartoonGlideAround: _steps_code_cartoon_09_glide_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_130___default.a,
  codeCartoonChangeCostumes: _steps_code_cartoon_10_change_costumes_zh_TW_png__WEBPACK_IMPORTED_MODULE_131___default.a,
  codeCartoonChooseMoreCharacters: _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default.a,
  // Talking Tales
  talesAddExtension: _steps_speech_add_extension_zh_TW_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  talesChooseSprite: _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default.a,
  talesSaySomething: _steps_talking_3_say_something_zh_TW_png__WEBPACK_IMPORTED_MODULE_134___default.a,
  talesAskAnswer: _steps_talking_13_ask_and_answer_zh_TW_png__WEBPACK_IMPORTED_MODULE_144___default.a,
  talesChooseBackdrop: _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default.a,
  talesSwitchBackdrop: _steps_talking_5_switch_backdrop_zh_TW_png__WEBPACK_IMPORTED_MODULE_136___default.a,
  talesChooseAnotherSprite: _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default.a,
  talesMoveAround: _steps_talking_7_move_around_zh_TW_png__WEBPACK_IMPORTED_MODULE_138___default.a,
  talesChooseAnotherBackdrop: _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default.a,
  talesAnimateTalking: _steps_talking_9_animate_zh_TW_png__WEBPACK_IMPORTED_MODULE_140___default.a,
  talesChooseThirdBackdrop: _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default.a,
  talesChooseSound: _steps_talking_11_choose_sound_zh_TW_gif__WEBPACK_IMPORTED_MODULE_142___default.a,
  talesDanceMoves: _steps_talking_12_dance_moves_zh_TW_png__WEBPACK_IMPORTED_MODULE_143___default.a
};


/***/ })

}]);
//# sourceMappingURL=zh_TW-steps.js.map